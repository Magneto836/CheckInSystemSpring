package com.example.punchcardsystem.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class StatisticsServiceImpl {

    /*
     * 要实现的功能：
     *  1. 统计相关数据进行排序
     *  2. 根据数据判断是否迟到 
     *
     *
     *
     *
     * */








}
