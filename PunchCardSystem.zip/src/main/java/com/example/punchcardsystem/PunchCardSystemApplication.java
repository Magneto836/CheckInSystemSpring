package com.example.punchcardsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PunchCardSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PunchCardSystemApplication.class, args);
	}

}
